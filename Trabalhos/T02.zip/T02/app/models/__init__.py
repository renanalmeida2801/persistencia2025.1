from .categoria import CategoriaFenomeno
from .entidade import EntidadeSobrenatural
from .relato import Relato
from .testemunha import Testemunha
from .registro import RegistroMultimidia
